def requires_2to3():
    return False
