# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""This module contains functions and classes for finding information about
affiliated packages and installing them.
"""

from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

__all__ = []
